package data.campaign.econ;

public class BoggledStationConstructionIDs {

    public static class BoggledStationConstructionIndustryIDs
    {
        public static final String ASTROPOLIS_STATION = "ASTROPOLIS_STATION";
    }
}