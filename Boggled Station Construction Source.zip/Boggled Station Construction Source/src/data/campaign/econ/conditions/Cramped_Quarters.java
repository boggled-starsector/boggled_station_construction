
package data.campaign.econ.conditions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.campaign.CircularFleetOrbit;
import com.fs.starfarer.campaign.CircularOrbit;
import com.fs.starfarer.campaign.CircularOrbitPointDown;
import com.fs.starfarer.campaign.CircularOrbitWithSpin;
import com.fs.starfarer.combat.entities.terrain.Planet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import data.campaign.econ.boggledTools;

public class Cramped_Quarters extends BaseHazardCondition implements MarketImmigrationModifier
{
    public Cramped_Quarters() { }

    public void advance(float amount)
    {
        super.advance(amount);
    }

    public void modifyIncoming(MarketAPI market, PopulationComposition incoming)
    {
        incoming.getWeight().modifyFlat(this.getModId(), this.getImmigrationBonus(), Misc.ucFirst(this.condition.getName().toLowerCase()));
    }

    protected float getImmigrationBonus()
    {
        MarketAPI market = this.market;
        int stationCrampedThreshold = Global.getSettings().getInt("boggledStationCrampedQuartersSizeGrowthReductionStarts");

        if (market.getSize() >= stationCrampedThreshold + 3)
        {
            return -200.0F;
        }
        else if (market.getSize() >= stationCrampedThreshold + 2)
        {
            return -100.0F;
        }
        else if (market.getSize() >= stationCrampedThreshold + 1)
        {
            return -50.0F;
        }
        else if (market.getSize() >= stationCrampedThreshold)
        {
            return -25.0F;
        }
        else
        {
            return 0.0F;
        }
    }

    public void apply(String id)
    {
        super.apply(id);

        if(Global.getSettings().getBoolean("boggledStationCrampedQuartersEnabled"))
        {
            //Market growth modifier
            this.market.addTransientImmigrationModifier(this);
        }

        if(Global.getSettings().getInt("boggledStationHazardRatingModifier") != 0)
        {
            //Market hazard modifier
            float hazard = (float)Global.getSettings().getInt("boggledStationHazardRatingModifier") / 100.0F;
            this.market.getHazard().modifyFlat(id, hazard, "Base station hazard");
        }
    }

    public void unapply(String id)
    {
        super.unapply(id);

        if(Global.getSettings().getBoolean("boggledStationCrampedQuartersEnabled"))
        {
            this.market.removeTransientImmigrationModifier(this);
        }

        if(Global.getSettings().getInt("boggledStationHazardRatingModifier") != 0)
        {
            this.market.getHazard().unmodifyFlat(id);
        }
    }

    public Map<String, String> getTokenReplacements() { return super.getTokenReplacements(); }

    public boolean showIcon()
    {
        if(Global.getSettings().getBoolean("boggledStationCrampedQuartersEnabled"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded)
    {
        super.createTooltipAfterDescription(tooltip, expanded);
        tooltip.addPara("Population growth reduction begins at size %s and gets worse as size increases further.", 10.0F, Misc.getHighlightColor(), new String[]{(Global.getSettings().getInt("boggledStationCrampedQuartersSizeGrowthReductionStarts") + 0) + ""});
    }
}
