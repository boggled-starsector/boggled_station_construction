package data.campaign.econ.abilities;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberViewAPI;
import com.fs.starfarer.api.impl.campaign.abilities.BaseDurationAbility;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidBeltTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import data.campaign.econ.boggledTools;

public class Construct_Mining_Station extends BaseDurationAbility
{
    private float creditCost = Global.getSettings().getInt("boggledStationBuildCreditCost");
    private float crewCost = Global.getSettings().getInt("boggledStationBuildCrewCost");
    private float heavyMachineryCost = Global.getSettings().getInt("boggledStationBuildHeavyMachineryCost");
    private float metalCost = Global.getSettings().getInt("boggledStationBuildMetalCost");
    private float transplutonicsCost = Global.getSettings().getInt("boggledStationBuildTransplutonicsCost");

    public Construct_Mining_Station() { }

    @Override
    protected void activateImpl()
    {
        CampaignClockAPI clock = Global.getSector().getClock();
        SectorEntityToken playerFleet = Global.getSector().getPlayerFleet();

        CargoAPI playerCargo = playerFleet.getCargo();
        playerCargo.getCredits().subtract(creditCost);
        playerCargo.removeCommodity("metals", metalCost);
        playerCargo.removeCommodity("rare_metals", transplutonicsCost);
        playerCargo.removeCommodity("crew", crewCost);
        playerCargo.removeCommodity("heavy_machinery", heavyMachineryCost);

        StarSystemAPI system = playerFleet.getStarSystem();
        SectorEntityToken newMiningStation = system.addCustomEntity("boggled_mining_station" + clock.getCycle() + clock.getMonth() + clock.getDay(), system.getBaseName() + " Mining Station", "boggled_mining_station_small", playerFleet.getFaction().getId());

        //Set the mining station in an orbit that keeps it within the asteroid belt or asteroid field
        if(boggledTools.playerFleetInAsteroidBelt(playerFleet))
        {
            SectorEntityToken focus = boggledTools.getFocusOfAsteroidBelt(playerFleet);
            float orbitRadius = boggledTools.getDistanceBetweenTokens(focus, playerFleet);
            float orbitAngle = boggledTools.getAngleFromPlayerFleet(focus);

            newMiningStation.setCircularOrbitPointingDown(focus, orbitAngle + 5, orbitRadius, orbitRadius / 10.0F);
        }
        else if(boggledTools.playerFleetInAsteroidField(playerFleet))
        {
            OrbitAPI asteroidOrbit = boggledTools.getAsteroidFieldOrbit(playerFleet);
            newMiningStation.setOrbit(asteroidOrbit.makeCopy());
        }

        newMiningStation.setInteractionImage("illustrations", "orbital_construction");
        String systemName = system.getName();

        //Create the mining station market
        MarketAPI market = Global.getFactory().createMarket(systemName + clock.getCycle() + clock.getMonth() + clock.getDay() + "MiningStationMarket", newMiningStation.getName(), 3);
        market.setSize(3);

        market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
        market.setPrimaryEntity(newMiningStation);

        market.setFactionId(Global.getSector().getPlayerFleet().getFaction().getId());
        market.setPlayerOwned(true);

        market.addCondition(Conditions.POPULATION_3);
        market.addCondition(Conditions.ORE_MODERATE);
        market.addCondition(Conditions.RARE_ORE_MODERATE);
        market.addCondition("sprite_controller");
        market.addCondition("cramped_quarters");

        market.addIndustry(Industries.POPULATION);
        market.addIndustry(Industries.SPACEPORT);
        market.addIndustry(Industries.MINING);

        newMiningStation.setMarket(market);

        Global.getSector().getEconomy().addMarket(market, true);

        //If the player doesn't view the colony management screen within a few days of market creation, then there can be a bug related to population growth
        Global.getSector().getCampaignUI().showInteractionDialog(newMiningStation);
        //Global.getSector().getCampaignUI().getCurrentInteractionDialog().dismiss();

        market.addSubmarket("storage");
        StoragePlugin storage = (StoragePlugin)market.getSubmarket("storage").getPlugin();
        storage.setPlayerPaidToUnlock(true);
        market.addSubmarket("local_resources");

        boggledTools.surveyAll(market);
        boggledTools.refreshSupplyAndDemand(market);

        //Delete abandoned mining stations and transfer their cargo to the newly created one

        CargoAPI cargo = null;
        ArrayList<SectorEntityToken> stationsToDelete = new ArrayList<SectorEntityToken>();

        Iterator allEntitiesInSystem = playerFleet.getStarSystem().getAllEntities().iterator();
        while(allEntitiesInSystem.hasNext())
        {
            SectorEntityToken entity = (SectorEntityToken)allEntitiesInSystem.next();
            if(entity.hasTag("boggled_mining_station") && entity.getFaction().getId().equals("neutral"))
            {
                stationsToDelete.add(entity);
            }
        }
        allEntitiesInSystem = null;

        for(int i = 0; i < stationsToDelete.size(); i++)
        {
            cargo = stationsToDelete.get(i).getMarket().getSubmarket("storage").getCargo();
            if(!cargo.isEmpty())
            {
                market.getSubmarket("storage").getCargo().addAll(cargo);
            }
            playerFleet.getStarSystem().removeEntity(stationsToDelete.get(i));
        }

        //while(stationsToDelete.size() >= 1)
        //{
        //    playerFleet.getStarSystem().removeEntity(stationsToDelete.get(0));
        //}
    }

    @Override
    public boolean isUsable()
    {
        SectorEntityToken playerFleet = Global.getSector().getPlayerFleet();

        if (playerFleet.isInHyperspace() || Global.getSector().getPlayerFleet().isInHyperspaceTransition())
        {
            return false;
        }

        boolean playerHasResources = true;
        boolean miningStationCapReached = false;
        int miningStationsInSystem = 0;
        int miningStationCap = Global.getSettings().getInt("boggledMaxNumMiningStationsPerSystem");

        if(!(boggledTools.playerFleetInAsteroidBelt(playerFleet) || boggledTools.playerFleetInAsteroidField(playerFleet)))
        {
            return false;
        }

        if(miningStationCap == 0)
        {
            return false;
        }

        Iterator allEntitiesInSystem = playerFleet.getStarSystem().getAllEntities().iterator();
        while(allEntitiesInSystem.hasNext())
        {
            SectorEntityToken entity = (SectorEntityToken)allEntitiesInSystem.next();
            if(entity.hasTag("boggled_mining_station") && !entity.getFaction().getId().equals("neutral"))
            {
                miningStationsInSystem++;
            }
        }

        if(miningStationsInSystem >= miningStationCap)
        {
            miningStationCapReached = true;
        }

        CargoAPI playerCargo = playerFleet.getCargo();
        if(playerCargo.getCredits().get() < creditCost)
        {
            playerHasResources = false;
        }

        if(playerCargo.getCommodityQuantity("metals") < metalCost)
        {
            playerHasResources = false;
        }

        if(playerCargo.getCommodityQuantity("rare_metals") < transplutonicsCost)
        {
            playerHasResources = false;
        }

        if(playerCargo.getCommodityQuantity("crew") < crewCost)
        {
            playerHasResources = false;
        }

        if(playerCargo.getCommodityQuantity("heavy_machinery") < heavyMachineryCost)
        {
            playerHasResources = false;
        }

        return !this.isOnCooldown() && this.disableFrames <= 0 && !miningStationCapReached && playerHasResources;
    }

    @Override
    public boolean hasTooltip()
    {
        return true;
    }

    @Override
    public void createTooltip(TooltipMakerAPI tooltip, boolean expanded)
    {
        SectorEntityToken playerFleet = Global.getSector().getPlayerFleet();
        Color highlight = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        LabelAPI title = tooltip.addTitle("Construct Mining Station");
        float pad = 10.0F;
        tooltip.addPara("Construct a mining station in an asteroid belt or asteroid field. Expends %s credits, %s crew, %s heavy machinery, %s metals and %s transplutonics for construction.", pad, highlight, new String[]{(int)creditCost + "",(int)crewCost + "",(int)heavyMachineryCost +"", (int)metalCost + "", (int)transplutonicsCost +""});

        if (playerFleet.isInHyperspace() || Global.getSector().getPlayerFleet().isInHyperspaceTransition())
        {
            tooltip.addPara("You cannot construct a mining station in hyperspace.", bad, pad);
        }

        boolean playerFleetInAsteroidBelt = false;

        if (!playerFleet.isInHyperspace() && !Global.getSector().getPlayerFleet().isInHyperspaceTransition())
        {
            if(boggledTools.playerFleetInAsteroidBelt(playerFleet) || boggledTools.playerFleetInAsteroidField(playerFleet))
            {
                playerFleetInAsteroidBelt = true;
            }
        }

        boolean miningStationCapReached = false;
        int miningStationsInSystem = 0;
        int miningStationCap = Global.getSettings().getInt("boggledMaxNumMiningStationsPerSystem");

        if (!playerFleet.isInHyperspace() && !Global.getSector().getPlayerFleet().isInHyperspaceTransition())
        {
            Iterator allEntitiesInSystem = playerFleet.getStarSystem().getAllEntities().iterator();
            while(allEntitiesInSystem.hasNext())
            {
                SectorEntityToken entity = (SectorEntityToken)allEntitiesInSystem.next();
                if(entity.hasTag("boggled_mining_station") && !entity.getFaction().getId().equals("neutral"))
                {
                    miningStationsInSystem++;
                }
            }
        }

        if(miningStationsInSystem >= miningStationCap)
        {
            miningStationCapReached = true;
        }

        if (!playerFleet.isInHyperspace() && !Global.getSector().getPlayerFleet().isInHyperspaceTransition())
        {
            Iterator allEntitiesInSystem = playerFleet.getStarSystem().getAllEntities().iterator();
            while(allEntitiesInSystem.hasNext())
            {
                SectorEntityToken entity = (SectorEntityToken)allEntitiesInSystem.next();
                if(entity.hasTag("boggled_mining_station") && entity.getFaction().getId().equals("neutral"))
                {
                    tooltip.addPara("There is at least one abandoned player-built mining station in this system. If you construct a new mining station, any abandoned stations will be destroyed and any cargo stored on them will be transferred to the new station.", pad, highlight, new String[]{});
                }
            }
        }

        if(!playerFleetInAsteroidBelt)
        {
            tooltip.addPara("Your fleet is too far away from an asteroid belt or asteroid field to build a mining station.", bad, pad);
        }

        if(miningStationCapReached && miningStationCap == 0)
        {
            tooltip.addPara("Construction of player-built mining stations has been disabled in the settings.json file. To enable construction of mining stations, change the value boggledMaxNumMiningStationsPerSystem to something other than zero.", bad, pad);
        }
        else if (miningStationCapReached && miningStationCap == 1)
        {
            tooltip.addPara("Each system can only support one player-built mining station. The mining station that already exists must be abandoned before a new mining station can be built in this system.", bad, pad);
        }
        else if(miningStationCapReached && miningStationCap > 1)
        {
            tooltip.addPara("Each system can only support " + miningStationCap + " player-built mining stations. You must abandon one or more existing mining stations before a new mining station can be constructed in this system.", bad, pad);
        }

        CargoAPI playerCargo = playerFleet.getCargo();
        if(playerCargo.getCredits().get() < creditCost)
        {
            tooltip.addPara("Insufficient credits.", bad, pad);
        }

        if(playerCargo.getCommodityQuantity("crew") < crewCost)
        {
            tooltip.addPara("Insufficient crew.", bad, pad);
        }

        if(playerCargo.getCommodityQuantity("heavy_machinery") < heavyMachineryCost)
        {
            tooltip.addPara("Insufficient heavy machinery.", bad, pad);
        }

        if(playerCargo.getCommodityQuantity("metals") < metalCost)
        {
            tooltip.addPara("Insufficient metals.", bad, pad);
        }

        if(playerCargo.getCommodityQuantity("rare_metals") < transplutonicsCost)
        {
            tooltip.addPara("Insufficient transplutonics.", bad, pad);
        }
    }

    @Override
    public boolean isTooltipExpandable() { return false; }

    @Override
    protected void applyEffect(float v, float v1) { }

    @Override
    protected void deactivateImpl() { }

    @Override
    protected void cleanupImpl() { }
}