package data.campaign.econ.industries;

import java.awt.Color;
import java.util.Iterator;
import java.util.Random;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.CoreCampaignPluginImpl;
import com.fs.starfarer.api.impl.campaign.CoreScript;
import com.fs.starfarer.api.impl.campaign.events.CoreEventProbabilityManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposableLuddicPathFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposablePirateFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetRouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.MercFleetManagerV2;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.campaign.*;
import com.fs.starfarer.combat.entities.terrain.Planet;
import data.campaign.econ.BoggledStationConstructionIDs;
import data.campaign.econ.boggledTools;

public class Expand_Station extends BaseIndustry {

    @Override
    public void apply() { super.apply(true); }

    @Override
    public void unapply() {
        super.unapply();
    }

    @Override
    public void finishBuildingOrUpgrading() {
        super.finishBuildingOrUpgrading();
    }

    public float getBuildCost()
    {
        if(!Global.getSettings().getBoolean("boggledStationProgressiveIncreaseInCostsToExpandStation"))
        {
            return this.getSpec().getCost();
        }
        else
        {
            double cost = (this.getSpec().getCost() * (Math.pow(2, boggledTools.getNumberOfStationExpansions(this.market))));
            return (float)cost;
        }
    }

    @Override
    protected void buildingFinished()
    {
        super.buildingFinished();

        boggledTools.incrementNumberOfStationExpansions(this.market);

        this.market.removeIndustry("BOGGLED_STATION_EXPANSION",null,false);
    }

    @Override
    public void startBuilding() {
        super.startBuilding();
    }

    @Override
    public boolean isAvailableToBuild()
    {
        if(Global.getSettings().getBoolean("boggledStationCrampedQuartersEnabled") && Global.getSettings().getBoolean("boggledStationCrampedQuartersPlayerCanPayToIncreaseStationSize") && this.market.getPrimaryEntity().hasTag("station") && (11 > (Global.getSettings().getInt("boggledStationCrampedQuartersSizeGrowthReductionStarts") + boggledTools.getNumberOfStationExpansions(this.market))))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    @Override
    public boolean showWhenUnavailable()
    {
        return false;
    }

    @Override
    public String getUnavailableReason()
    {
        return "This text should never be seen. Tell Boggled about this on the forums and mention 'getUnavailableReason() in Expand_station'";
    }

    //These should remove the ability to install an AI core
    @Override
    public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode)
    {
        //this.addAICoreSection(tooltip, this.aiCoreId, mode);
    }

    @Override
    public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode)
    {
        /*
        float opad = 10.0F;
        FactionAPI faction = this.market.getFaction();
        Color color = faction.getBaseUIColor();
        Color dark = faction.getDarkUIColor();
        if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP && coreId == null) {
            tooltip.addPara("No AI core currently assigned. Click to assign an AI core from your cargo.", opad);
        } else {
            boolean alpha = coreId.equals("alpha_core");
            boolean beta = coreId.equals("beta_core");
            boolean gamma = coreId.equals("gamma_core");
            if (alpha) {
                this.addAlphaCoreDescription(tooltip, mode);
            } else if (beta) {
                this.addBetaCoreDescription(tooltip, mode);
            } else if (gamma) {
                this.addGammaCoreDescription(tooltip, mode);
            }

        }
         */
    }

    @Override
    public void addInstalledItemsSection(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded)
    {
        /*
        float opad = 10.0F;
        FactionAPI faction = this.market.getFaction();
        Color color = faction.getBaseUIColor();
        Color dark = faction.getDarkUIColor();
        LabelAPI heading = tooltip.addSectionHeading("Items", color, dark, Alignment.MID, opad);
        boolean addedSomething = false;
        if (this.aiCoreId != null) {
            AICoreDescriptionMode aiCoreDescMode = AICoreDescriptionMode.INDUSTRY_TOOLTIP;
            this.addAICoreSection(tooltip, this.aiCoreId, aiCoreDescMode);
            addedSomething = true;
        }

        addedSomething |= this.addNonAICoreInstalledItems(mode, tooltip, expanded);
        if (!addedSomething) {
            heading.setText("No items installed");
        }
         */
    }
}
